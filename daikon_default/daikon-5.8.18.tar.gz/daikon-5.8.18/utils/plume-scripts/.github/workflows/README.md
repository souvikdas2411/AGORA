There is no need for GitHub Actions because CircleCI runs CI for this repository.
