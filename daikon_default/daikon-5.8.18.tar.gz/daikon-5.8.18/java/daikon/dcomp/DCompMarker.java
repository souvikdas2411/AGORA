package daikon.dcomp;

/**
 * This is the type of the extra formal parameter in methods that have been instrumented by DynComp.
 * The original, uninstrumented version of the method also exists in the class file.
 */
public interface DCompMarker {}
