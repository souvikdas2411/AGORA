package daikon.dcomp;

/** Classes implementing this interface have been instrumented by DynComp. */
public interface DCompInstrumented {
  public boolean equals_dcomp_instrumented(Object o);
}
